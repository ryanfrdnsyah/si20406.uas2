package io.conta.view.login

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import io.conta.R
import io.conta.view.main.MainActivity
import io.conta.view.register.RegisterActivity
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    lateinit var sharedPreference: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sharedPreference = getSharedPreferences("Study", Context.MODE_PRIVATE)

        txt_register.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        btn_login.setOnClickListener {
            val username = et_username.text.toString()
            val password = et_password.text.toString()

            if (!username.isNullOrEmpty() && !password.isNullOrEmpty()){
                FirebaseAuth.getInstance().signInWithEmailAndPassword(username,password)
                    .addOnCompleteListener{

                        if (!it.isSuccessful){ return@addOnCompleteListener
                            val intent = Intent (this, MainActivity::class.java)
                            startActivity(intent)
                        }
                        else
                            Toast.makeText(this, "Succesfully Login", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                    }
                    .addOnFailureListener{
                        showDialog()
                        Toast.makeText(this, "Email/Password incorrect", Toast.LENGTH_SHORT).show()

                    }

//                val intent = Intent(this, MainActivity::class.java)
//                val editor = sharedPreference.edit()
//                editor.putString("name", et_username.text.toString())
//                editor.apply()
//                startActivity(intent)
//                finishAffinity()
            } else {
                showDialog()
            }
        }
    }

    private fun showDialog() {
        AlertDialog.Builder(this)
            // Judul
        .setTitle("Error !")
        // Pesan yang di tamopilkan
        .setMessage("Username atau password salah")
        .setPositiveButton("Ok", { dialogInterface, i ->
            dialogInterface.dismiss()
        })

        .show()

    }
}

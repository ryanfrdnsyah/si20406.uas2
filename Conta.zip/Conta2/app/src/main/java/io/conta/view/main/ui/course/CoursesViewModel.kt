package io.conta.view.main.ui.course

import androidx.lifecycle.ViewModel

class CoursesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}

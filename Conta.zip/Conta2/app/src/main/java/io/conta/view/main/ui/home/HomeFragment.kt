package io.conta.view.main.ui.home

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import io.conta.R
import io.conta.view.register.RegisterActivity
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_home.view.*

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    lateinit var homeAdapter: HomeAdapter

    @SuppressLint("SetTextI18n")
    val data = arrayListOf<String>()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProviders.of(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        val db = Firebase.firestore
        root.txt_name.text = "Selamat datang di Conta! :)"

        db.collection("contacts")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val name = document.data["name"]
                    val phone = document.data["phone"]
                    val builder = StringBuilder()
                    builder.append(name).append(" ").append(phone)

                    data.add(builder.toString())
                    Log.d(TAG, "${builder.toString()}")
                }

                println(data)
                root.rv_new_courses.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
                homeAdapter = HomeAdapter(context!!, data, "Home")
                root.rv_new_courses.adapter = homeAdapter
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents.", exception)
            }

        return root
    }
}
